import React, { useState } from 'react';
import './Home.css';  // Custom CSS for styling

const Home = () => {
  const [storyPrompt, setStoryPrompt] = useState('');
  const [wordCount, setwordCount] = useState('');
  const [genre, setGenre] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault(); // Prevent default form submission behavior
    if (!storyPrompt || !wordCount || !genre) {
        alert('Please fill out all fields.');
        return;
    }

    // Format the input data according to your specified format
    const inputData = `Generate a ${genre} story about ${storyPrompt} in ${wordCount} words. Only output the story and don't include instructions.`;

    try {
        const response = await fetch("https://2fd9-34-126-156-31.ngrok-free.app/", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ input: inputData }), // Send formatted input
        });

        if (!response.ok) {
            throw new Error("Network response was not ok");
        }

        const data = await response.json();
        console.log(data); // Handle the response data as needed
    } catch (error) {
        console.error("Error:", error);
    }
};


  return (
    <div className="page-container">
      <div className="header">
        <h1>Katha-Vaachak</h1>
      </div>
      
      <div className="bottom-section">
        <form onSubmit={handleSubmit} className="form-container">
          {/* Story input field */}
          <textarea
            className="story-input"
            value={storyPrompt}
            onChange={(e) => setStoryPrompt(e.target.value)}
            placeholder="Enter your story prompt here..."
          />
          
          {/* Genre dropdown */}
          <div className="input-group">
            <label htmlFor="genre" id="generelabel">Genre</label>
            <select
              id="genre"
              value={genre}
              onChange={(e) => setGenre(e.target.value)}
              className="dropdown"
            >
              <option value="">Genre</option>
              <option value="horror">Horror</option>
              <option value="moral">Moral</option>
              <option value="folk-tales">Folk Tales</option>
              <option value="mythology">Mythology</option>
              <option value="fairy-tales">Fairy Tales</option>
              <option value="general">General</option>
              <option value="fantasy">Fantasy</option>
              <option value="adventureous">Adventureous</option>
              <option value="Romantic">Romantic</option>
            </select>
          </div>

          {/* Character count input */}
          <div className="input-group">
            <label htmlFor="wordCount" id="lengthlabel">Length</label>
            <input
              type="number"
              id="wordCount"
              value={wordCount}
              onChange={(e) => setwordCount(e.target.value)}
              placeholder="Word Count"
              min="100"
              max="10000"
              className="word-input"
            />
          </div>

          <button type="submit" className="submit-btn">Generate Story</button>
        </form>
      </div>
    </div>
  );
};

export default Home;
