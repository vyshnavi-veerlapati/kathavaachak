import React from 'react';
import './ReadBooks.css';  // Importing the CSS file

const ReadBooks = () => {
  // Array of 20 books with their titles, PDFs, and images
  const books = [
    { title: 'Why Do Sunflowers Love the Sun_', pdf: 'Why Do Sunflowers Love the Sun_.pdf', image: 'Why Do Sunflowers Love the Sun.png' },
    { title: 'Always Be Good – Be Nice Series Book 5', pdf: 'Always Be Good – Be Nice series book 5, revised edition.pdf', image: 'nice_series_5.jpg' },
    { title: 'An Unexpected Adventure – Wordless Fun', pdf: 'An Unexpected Adventure – Wordless Fun.pdf', image: 'explosives.jpg' },
    { title: 'Every Minute Counts', pdf: 'Every Minute Counts.pdf', image: 'every_minute_counts.jpg' },
    { title: 'Fossils, Tales of Long Ago', pdf: 'Fossils_ Tales of Long Ago.pdf', image: 'fossils.jpg' },
    { title: "Gods Story Book", pdf: "Gods Story Book.pdf", image: 'gods_story.png' },
    { title: 'Hippo Naughty Hippo', pdf: 'Hippo Naughty Hippo.pdf', image: 'naughty_hippo.png' },
    { title: 'Hungry on the Steps – Early Learning', pdf: 'Hungry on the Steps – Early Learning.pdf', image: 'hungry_steps.png' },
    { title: 'Meera and Ameera – Imaginary Friends', pdf: 'Meera and Ameera – Imaginary Friends.pdf', image: 'meera_ameera.png' },
    { title: 'My Wild Life – Early Reader', pdf: 'My Wild Life – Early Reader.pdf', image: 'wild_life.png' },
    { title: 'Rain', pdf: 'Rain.pdf', image: 'rain.png' },
    { title: 'Rat Cat – Early Reader', pdf: 'Rat Cat – Early Reader.pdf', image: 'rat_cat.png' },
    { title: 'Robin Hood – Mashed Myths', pdf: 'Robin Hood – Mashed Myths.pdf', image: 'robin_hood.png' },
    { title: 'Teddys Strange Problem – Understanding Feelings', pdf: 'Teddys Strange Problem – Understanding Feelings.pdf', image: 'teddy_problem.png' },
    { title: 'The Bee and the Elephant', pdf: 'The Bee and the Elephant.pdf', image: 'bee_elephant.png' },
    { title: 'The Clever Tortoise', pdf: 'The Clever Tortoise.pdf', image: 'clever_tortoise.png' },
    { title: 'The Life Story of Ayrton Senna', pdf: 'The Life Story of Ayrton Senna.pdf', image: 'ayrton_senna.png' },
    { title: 'The Little Bird Blue', pdf: 'The Little Bird Blue.pdf', image: 'bird_blue.png' },
    { title: 'The Magic Pitcher – Tales from the Sanskrit for Children', pdf: 'The Magic Pitcher – Tales From the Sanskrit for Children.pdf', image: 'magic_pitcher.png' },
    { title: 'The Mighty Solar Panel – A Story of Solar Energy', pdf: 'The Mighty Solar Panel – A story of solar energy.pdf', image: 'solar_panel.png' },
  ];

  return (
    <div className="read-books-page">
      <h1 id="heading">Read Story Books</h1>
      <div className="books-grid">
        {books.map((book, index) => (
          <div key={index} className="book">
            <a href={`${process.env.PUBLIC_URL}/pdfs/${book.pdf}`} target="_blank" rel="noopener noreferrer">
              <img src={`${process.env.PUBLIC_URL}/images/${book.image}`} alt={book.title} className="book-image" />
              <p>{book.title}</p>
            </a>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ReadBooks;
